export const BREAKPOINTS = {
	lg: '900px',
};
