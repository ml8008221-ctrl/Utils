package com.example.core.models;

import com.adobe.cq.export.json.ContainerExporter;

public interface ColumnControlModel extends ContainerExporter {

	String getColumnLayout();

}
