# Column Control in AEM SPA - React

This project is created
using [Adobe's AEM Project Archetype 39](https://github.com/adobe/aem-project-archetype) that
implements a **column-control component (container component)** in an **AEM SPA - React app**.
It contains the column control component implementation along with a demo AEM page in addition to
the archetype's example content. This repository complements the column control implementation blog
on https://blog.3sharecorp.com.

## Modules

The main parts of the repository are:

* core: Java bundle containing all core functionality like OSGi services, listeners or schedulers,
  as well as component-related Java code such as servlets or request filters.
    * [ColumnControlModel](https://bitbucket.org/3share-lab/column-control-in-aem-spa/src/main/core/src/main/java/com/example/core/models/ColumnControlModel.java):
      Sling Model for the column-control component.
* ui.apps: contains the /apps (and /etc) parts of the project, ie JS&CSS clientlibs, components, and
  templates
    * [columncontrol AEM component](https://bitbucket.org/3share-lab/column-control-in-aem-spa/src/main/ui.apps/src/main/content/jcr_root/apps/aem-spa-container-component/components/columncontrol/):
      AEM component
* ui.frontend: dedicated front-end build mechanism for React
    * [ColumnControl React component](https://bitbucket.org/3share-lab/column-control-in-aem-spa/src/main/ui.frontend/src/components/ColumnControl/index.tsx):
      React component implementation for columncontrol component.
    * [ColumnControl styling](https://bitbucket.org/3share-lab/column-control-in-aem-spa/src/main/ui.frontend/src/components/ColumnControl/styles.ts):
      Frontend styles for column control component
* ui.content: contains sample content using the components from the ui.apps
    * [Demo Page](https://bitbucket.org/3share-lab/column-control-in-aem-spa/src/main/ui.content/src/main/content/jcr_root/content/aem-spa-container-component/us/en/home/):
      Sample page with column control component
* all: a single content package that embeds all of the compiled modules (bundles and content
  packages) including any vendor dependencies

## How to build

To build all the modules run in the project root directory the following command with Maven 3:

    mvn clean install

To build all the modules and deploy the `all` package to a local instance of AEM, run in the project
root directory the following command:

    mvn clean install -PautoInstallSinglePackage

Or to deploy it to a publish instance, run

    mvn clean install -PautoInstallSinglePackagePublish

Or alternatively

    mvn clean install -PautoInstallSinglePackage -Daem.port=4503

Or to deploy only the bundle to the author, run

    mvn clean install -PautoInstallBundle

Or to deploy only a single content package, run in the sub-module directory (i.e `ui.apps`)

    mvn clean install -PautoInstallPackage

## ClientLibs

The frontend module is made available using
an [AEM ClientLib](https://helpx.adobe.com/experience-manager/6-5/sites/developing/using/clientlibs.html).
When executing the NPM build script, the app is built and
the [`aem-clientlib-generator`](https://github.com/wcm-io-frontend/aem-clientlib-generator) package
takes the resulting build output and transforms it into such a ClientLib.

A ClientLib will consist of the following files and directories:

- `css/`: CSS files which can be requested in the HTML
- `css.txt` (tells AEM the order and names of files in `css/` so they can be merged)
- `js/`: JavaScript files which can be requested in the HTML
- `js.txt` (tells AEM the order and names of files in `js/` so they can be merged
- `resources/`: Source maps, non-entrypoint code chunks (resulting from code splitting), static
  assets (e.g. icons), etc.

## Maven settings

The project comes with the auto-public repository configured. To setup the repository in your Maven
settings, refer to:

    http://helpx.adobe.com/experience-manager/kb/SetUpTheAdobeMavenRepository.html
